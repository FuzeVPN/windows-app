/*
 *  ovpn-dco-win OpenVPN protocol accelerator for Windows
 *
 *  Copyright (C) 2020-2021 OpenVPN Inc <sales@openvpn.net>
 *
 *  Author:	Lev Stipakov <lev@openvpn.net>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#pragma once

#include <ntdef.h>
#include <wdftypes.h>
#include <wdm.h>
#include <wsk.h>

#include "pktid.h"

#define OVPN_SOCKET_RX_PACKET_BUFFER_SIZE 2048
#define OVPN_BUFFER_HEADROOM 30 // prepend TCP size (2 bytes) + max front crypto overhead (28 bytes)
#define OVPN_BUFFER_TAILROOM 16 // max AEAD auth tag appended at packet tail (epoch mode)

DECLARE_HANDLE(OVPN_BUFFER_POOL);
DECLARE_HANDLE(OVPN_TX_BUFFER_POOL);
DECLARE_HANDLE(OVPN_RX_BUFFER_POOL);

DECLARE_HANDLE(OVPN_BUFFER_QUEUE);

struct OVPN_TX_BUFFER
{
    WSK_BUF_LIST WskBufList;

    // points to the beginning of data
    PUCHAR Data;

    // points to the end of data
    PUCHAR Tail;

    // data length
    SIZE_T Len;

    // describes MDL for buffer, used by Winsock Kernel
    PMDL Mdl;

    OVPN_TX_BUFFER_POOL Pool;

    // the peer this buffer is being sent to, with a reference held, while a worker has it
    struct OvpnPeerContext* Peer;

    LIST_ENTRY PoolListEntry;

    // control channel packet, not data channel
    BOOLEAN ControlChannel;

    // set while this buffer is counted in device->TxDataInFlight (datapath worker path)
    BOOLEAN CountedInFlight;

    // set only when a write request is parked waiting for this send, which is TCP only
    WDFQUEUE IoQueue;

#pragma warning(suppress:4200) //nonstandard extension used: zero-sized array in struct/union
    UCHAR Head[];
};

struct OVPN_RX_BUFFER
{
    // points to the beginning of data
    PUCHAR Data;

    // points to the end of data
    PUCHAR Tail;

    // data length
    SIZE_T Len;

    LIST_ENTRY PoolListEntry;

    LIST_ENTRY QueueListEntry;

    OVPN_RX_BUFFER_POOL Pool;

    // From receive to delivery of a data packet: its peer, with a reference held,
    // what decryption found, and the sender's address in MP mode (else AF_UNSPEC)
    struct OvpnPeerContext* Peer;
    OvpnCryptoRxResult CryptoResult;
    NTSTATUS DecryptStatus;
    volatile LONG Decrypted;
    SOCKADDR_INET Remote;

    #pragma warning(suppress:4200) //nonstandard extension used: zero-sized array in struct/union
    UCHAR Head[];
};

template <class BUF>
UCHAR*
OvpnBufferPut(_In_ BUF* buf, SIZE_T len)
{
    UCHAR* tmp = buf->Tail;
    buf->Tail += len;
    buf->Len += len;

    return tmp;
}

template <class BUF>
VOID
OvpnBufferTrim(_In_ BUF* buf, SIZE_T len)
{
    buf->Len = len;
    buf->Tail = buf->Data + len;
}

template <class BUF>
VOID
OvpnBufferPull(_In_ BUF* buf, SIZE_T len)
{
    buf->Len -= len;
    buf->Data += len;
}

UCHAR*
OvpnTxBufferPush(_In_ OVPN_TX_BUFFER* work, SIZE_T len);

_Must_inspect_result_
NTSTATUS
OvpnTxBufferPoolCreate(OVPN_TX_BUFFER_POOL* handle, VOID* ctx, volatile LONG* inFlight);

VOID*
OvpnTxBufferPoolGetContext(OVPN_TX_BUFFER_POOL handle);

_Must_inspect_result_
NTSTATUS
OvpnTxBufferPoolGet(_In_ OVPN_TX_BUFFER_POOL handle, _Outptr_ OVPN_TX_BUFFER** buffer);

VOID
OvpnTxBufferPoolPut(_In_ OVPN_TX_BUFFER* buffer);

_Must_inspect_result_
NTSTATUS
OvpnRxBufferPoolGet(_In_ OVPN_RX_BUFFER_POOL handle, _Outptr_ OVPN_RX_BUFFER** buffer);

VOID
OvpnRxBufferPoolPut(_In_ OVPN_RX_BUFFER* buffer);

_Must_inspect_result_
NTSTATUS
OvpnRxBufferPoolCreate(OVPN_RX_BUFFER_POOL* handle);

NTSTATUS
OvpnBufferQueueCreate(OVPN_BUFFER_QUEUE* handle);

VOID
OvpnBufferQueueEnqueue(OVPN_BUFFER_QUEUE handle, PLIST_ENTRY listEntry);

VOID
OvpnBufferQueueEnqueueHead(OVPN_BUFFER_QUEUE handle, PLIST_ENTRY listEntry);

// Moves every entry of from onto the empty list to without walking it; from is left empty.
static inline
VOID
OvpnListMoveAll(_Inout_ PLIST_ENTRY from, _Out_ PLIST_ENTRY to)
{
    if (IsListEmpty(from)) {
        InitializeListHead(to);
        return;
    }
    to->Flink = from->Flink;
    to->Blink = from->Blink;
    to->Flink->Blink = to;
    to->Blink->Flink = to;
    InitializeListHead(from);
}

LIST_ENTRY*
OvpnBufferQueueDequeue(OVPN_BUFFER_QUEUE handle);

VOID
OvpnRxBufferPoolDelete(OVPN_BUFFER_POOL handle);

VOID
OvpnTxBufferPoolDelete(OVPN_BUFFER_POOL handle);

VOID
OvpnBufferQueueDelete(OVPN_BUFFER_QUEUE handle);
