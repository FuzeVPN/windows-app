/* SPDX-License-Identifier: MIT
 *
 * Copyright (C) 2017-2026 WireGuard LLC. All Rights Reserved.
 */

package memmod

const imageFileProcess = IMAGE_FILE_MACHINE_ARM64
